
import java.awt.Canvas;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author frias
 */
public class Lienzo extends Canvas {
    Calle calle1,calle2;
    Semaforo s1;
    Semaforo2 s2;
    Carros[] carros1 = new Carros[2];
    Carro2[] carros2 = new Carro2[2];
    
    
    
    public Lienzo(){
        s1 = new Semaforo(this,230,15);
        s2=new Semaforo2(this,500,400);
        calle1 = new Calle();
        calle2 = new Calle();
       
        carros1[0] = new Carros(320,0,3,s1,this);
        carros1[1] = new Carros(420,600,4,s1,this);
       
        carros2[0] = new Carro2(0,310,1,s2,this);
        carros2[1] = new Carro2(500,250,2,s2,this);
       
         for(int i=0; i<2;i++){
            carros1[i].start();
            carros2[i].start();
        }
        // carros2[0].start();
        s1.start();
        s2.start();
        
        
       
    }
    
    
     @Override
    public void paint(Graphics g) {
        super.paint(g); //To change body of generated methods, choose Tools | Templates.
        Graphics2D g2 = (Graphics2D) g;
        
        this.setBackground(Color.DARK_GRAY);
        
        calle1.pintarVertical(g2);
        calle2.pintarHorizontal(g2);
        
        
        
         for(int i=0; i<2; i++){
            carros1[i].pintar(g2);
            carros2[i].pintar(g2);
        }
        
        s1.pintar(g2);
       s2.pintar(g2);
      
    }
}
