
import java.awt.Color;
import java.awt.Graphics2D;
import static java.lang.Thread.sleep;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author frias
 */
public class Carros extends Thread{
      int x, y ,rumbo;
    Color color;
    Lienzo Lienzo;
    Semaforo semaforo;
    Semaforo2 semaforo2;
    int desplazamiento = (int) (Math.random()*7+5);
        
    
    public Carros(int x, int y, int rumbo, Semaforo s, Lienzo l){
        this.x = x;
        this.y = y;
        this.rumbo = rumbo;
        color = new Color((int) (Math.random()*200+10),(int) (Math.random()*200+10),(int) (Math.random()*200+10));
        semaforo = s;
        this.Lienzo = l;
    }
    
     public void pintar(Graphics2D g){
        g.setColor(color);
        switch(rumbo){
            case 3: 
                g.fillRect(x, y, 40, 60);
                g.setColor(Color.black);
                g.fillOval(x-5, y+8, 4, 10);
                g.fillOval(x+40, y+8, 4, 10);
                g.fillOval(x-5, y+35, 4, 10);
                g.fillOval(x+40, y+35, 4, 10);
                break;
                  case 4: 
                g.fillRect(x, y, 40, 60);
                g.setColor(Color.black);
                g.fillOval(x-5, y+8, 4, 10);
                g.fillOval(x+40, y+8, 4, 10);
                g.fillOval(x-5, y+35, 4, 10);
                g.fillOval(x+40, y+35, 4, 10);
                break;
        }
    }
     
       public void mover(){
        switch(rumbo){
            case 3:
                y+=desplazamiento;
                if(y>700){
                    y=(int) (Math.random()*50+100)*-1;
                    desplazamiento = (int) (Math.random()*7+5);
                }
                break;
                case 4:
                y-=desplazamiento;
                if(y<-100){
                    y=(int) (Math.random()*100+650);
                    desplazamiento = (int) (Math.random()*7+5);
                }
                break;
        }
    }
       
        @Override
    public void run() {
        super.run(); //To change body of generated methods, choose Tools | Templates.
        while(true){
            try {
                switch (rumbo){
                    case 3://norte a sur
                        if(y>=130 && y<=150){
                            if(semaforo.color==1){//verde
                                mover();
                            }
                        } else{
                            mover();
                        }
                        Lienzo.repaint();
                        break;
                    case 4://sur a norte
                        if(y>=420 && y<=430){
                            if(semaforo.color==1){//verde
                                mover();
                            }
                        } else{
                            mover();
                        }
                        Lienzo.repaint();
                        break;
                }
                sleep(100);
            } catch (InterruptedException ex) {
                Logger.getLogger(Carros.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
}
