
import java.awt.Color;
import java.awt.Graphics2D;
import static java.lang.Thread.sleep;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author frias
 */
public class Carro2 extends Thread{
    int x, y ,rumbo;
    Color color;
    Lienzo Lienzo;
    Semaforo2 semaforo2;
    int desplazamiento = (int) (Math.random()*7+5);
        
    
    public Carro2(int x, int y, int rumbo, Semaforo2 s, Lienzo l){
        this.x = x;
        this.y = y;
        this.rumbo = rumbo;
        color = new Color((int) (Math.random()*200+10),(int) (Math.random()*200+10),(int) (Math.random()*200+10));
        semaforo2 = s;
        this.Lienzo = l;
    }
    
     public void pintar(Graphics2D g){
        g.setColor(color);
        switch(rumbo){
            case 1:
                g.fillRect(x, y, 60, 40);
                g.setColor(Color.black);
                g.fillOval(x+8, y-5, 10, 4);
                g.fillOval(x+8, y+40, 10, 4);
                g.fillOval(x+35, y-5, 10, 4);
                g.fillOval(x+35, y+40, 10, 4);
                break;
            case 2:
                g.fillRect(x, y, 60, 40);
              
                g.setColor(Color.black);
                g.fillOval(x+8, y-5, 10, 4);
                g.fillOval(x+8, y+40, 10, 4);
                g.fillOval(x+35, y-5, 10, 4);
                g.fillOval(x+35, y+40, 10, 4);
                break;
        }
    }
     
       public void mover(){
        switch(rumbo){
            case 1:
                x+=desplazamiento;
                if(x>850){
                    x=(int) (Math.random()*50+100)*-1;
                   desplazamiento = (int) (Math.random()*80+90);                    
                }
                break;
            case 2:
                x-=desplazamiento;
                if(x<-100){
                    x=(int) (Math.random()*100+900);
                    desplazamiento = (int) (Math.random()*80+90);
                }
        }
    }
       
        @Override
    public void run() {
        super.run(); //To change body of generated methods, choose Tools | Templates.
        while(true){
            try {
                switch (rumbo){
                    case 1://oeste a este
                        if(x>=190 && x<=200){
                            if(semaforo2.color==1){//verde
                                mover();
                            }
                        } else{
                            mover();
                        }
                        Lienzo.repaint();
                        break;
                    case 2://este a oeste
                        if(x>=500 && x<=520){
                            if(semaforo2.color==1){//verde
                                mover();
                            }
                        } else{
                            mover();
                        }
                        Lienzo.repaint();
                        break;
                }
                sleep(10);
            } catch (InterruptedException ex) {
                Logger.getLogger(Carros.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
}
