
import java.awt.Color;
import java.awt.Graphics2D;
import static java.lang.Thread.sleep;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author frias
 */
public class Semaforo2 extends Thread{
     int color;
    Lienzo puntero;
    int x,y;

 
    public  Semaforo2(Lienzo l,int posX,int posY){
        color=3;
        puntero=l;
        x=posX;
        y=posY;
    }
    
    @Override
    public void run() {
        super.run(); //To change body of generated methods, choose Tools | Templates.
        while(true){
            try {
                switch(color){
               case 1:
                verde(); 
                break;
                case 2:
                amarillo();
                break;
                case 3:
                rojo(); 
                break;
                }
            } catch (InterruptedException ex) {
                Logger.getLogger(Semaforo.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
    public void verde() throws InterruptedException{
         puntero.repaint();
         sleep(10000);
          color = 2;
         // System.out.print("verde "+color);
    }
    public void rojo() throws InterruptedException{
         puntero.repaint();
         sleep(10000);
         color = 1;
        // System.out.print("rojo "+color);
    }
    public void amarillo() throws InterruptedException{
        puntero.repaint();
         sleep(4000);
         color = 3;
        // System.out.print("amarillo "+color);
    }
     public void pintar(Graphics2D g){
        
        g.setColor(Color.orange);
        g.fillRect(x, y, 70, 170);
        
         //ROJOSCURO
        g.setColor(new Color(165,44,2));
        g.fillOval(x+15, y+10, 40, 40);

        //amarilloscuro
        g.setColor(new Color(205,190,58));
        g.fillOval(x+15, y+60, 40, 40);
        
        
        //verdescuro
        g.setColor(new Color(18,121,5));
        g.fillOval(x+15, y+110, 40, 40);
        
        
        
                
        switch(color){
            case 1://verde
                g.setColor(Color.GREEN);
                g.fillOval(x+15, y+110, 40, 40);
                 //System.out.print("verde "+color);
                break;
            case 2://amarillo
                g.setColor(Color.YELLOW);
                g.fillOval(x+15, y+60, 40, 40);
                // System.out.print("amarillo "+color);
                break;
            case 3://rojo
                g.setColor(Color.red);
                g.fillOval(x+15, y+10, 40, 40);
                //System.out.print("rojo "+color);
                break;

        }
    }
    
}
